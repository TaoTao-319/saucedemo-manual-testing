from pathlib import Path
import json
prefix=Path(__file__).with_name('recheck_site.py').read_text(encoding='utf-8').split('with sync_playwright() as pw:')[0]
exec(compile(prefix,'recheck_helpers','exec'))
results=json.loads((OUT/'results.json').read_text(encoding='utf-8'))
with sync_playwright() as pw:
    browser=pw.chromium.launch()
    for user in ['standard_user','problem_user']:
        for repetition in range(1,3):
            label=user+'-odd-item-'+str(repetition);context,page=session(browser,label);login(page,user)
            add(page,'Sauce Labs Bolt T-Shirt');page.locator('[data-test="shopping-cart-link"]').click();expect(page.locator('[data-test="title"]')).to_have_text('Your Cart')
            result={'requested':'Sauce Labs Bolt T-Shirt','actual':page.locator('.cart_item .inventory_item_name').all_text_contents(),'screenshot':shot(page,label),'trace':'evidence/'+OUT.name+'/'+label+'.zip'}
            for observation in results['accounts']:
                if observation['user']==user and observation['repetition']==repetition:observation['restricted_add']=result
            print(label,result['actual'],flush=True);close(context,label);save()
    browser.close()
results['finished_at']=datetime.now(timezone(timedelta(hours=8))).isoformat();save()
