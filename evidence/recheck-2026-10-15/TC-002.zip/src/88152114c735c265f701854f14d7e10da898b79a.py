import json,re,sys,traceback
from datetime import datetime,timezone,timedelta
from pathlib import Path
from urllib.parse import urljoin
from playwright.sync_api import sync_playwright,expect

ROOT=Path('F:/projects/saucedemo-manual-testing')
OUT=ROOT/'evidence/recheck-2026-10-15'
OUT.mkdir(parents=True,exist_ok=True)
BASE='https://www.saucedemo.com/'
results={'started_at':datetime.now(timezone(timedelta(hours=8))).isoformat(),'baseline':[],'accounts':[],'empty_cart':[]}
cache={}
expect.set_options(timeout=20000)

def save():
    (OUT/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')

def route_script(route):
    url=route.request.url
    if url not in cache:
        response=route.fetch(timeout=60000,max_retries=2)
        if not response.ok:
            route.fulfill(response=response);return
        cache[url]={'status':response.status,'body':response.body(),'headers':{k:v for k,v in response.headers.items() if k not in {'content-length','content-encoding','transfer-encoding'}}}
    route.fulfill(**cache[url])

def session(browser,name):
    context=browser.new_context(viewport={'width':1366,'height':900})
    context.route(re.compile(r'https://www\.saucedemo\.com/assets/.*\.js'),route_script)
    context.tracing.start(screenshots=True,snapshots=True,sources=True)
    page=context.new_page();page.set_default_timeout(12000)
    page.goto(BASE,wait_until='domcontentloaded',timeout=90000)
    page.locator('#user-name').wait_for()
    return context,page

def close(context,name):context.tracing.stop(path=str(OUT/(name+'.zip')));context.close()
def login(page,user='standard_user',password='secret_sauce'):
    page.locator('#user-name').fill(user);page.locator('#password').fill(password);page.locator('#login-button').click()
    if user in {'standard_user','problem_user','visual_user','performance_glitch_user'} and password=='secret_sauce':
        page.wait_for_url('**/inventory.html',timeout=60000)
        expect(page.locator('.inventory_item')).to_have_count(6)
def shot(page,name):
    page.screenshot(path=str(OUT/(name+'.png')),full_page=True)
    return 'evidence/'+OUT.name+'/'+name+'.png'
def check(page,code,fn):
    try:actual=fn();status='Pass'
    except Exception as error:actual=str(error);status='Fail'
    results['baseline'].append({'id':code,'status':status,'actual':actual,'url':page.url,'screenshot':shot(page,code)})
    save();print(code,status,flush=True)
def text(locator):return locator.inner_text().strip()
def items(page):
    values=[]
    for item in page.locator('.inventory_item').all():
        values.append({'name':text(item.locator('.inventory_item_name')),'price':text(item.locator('.inventory_item_price')),'image':urljoin(BASE,item.locator('img.inventory_item_img').get_attribute('src')),'description':text(item.locator('.inventory_item_desc'))})
    return values
def add(page,name):page.locator('.inventory_item').filter(has=page.get_by_text(name,exact=True)).get_by_role('button',name='Add to cart',exact=True).click()
def checkout(page):
    page.locator('[data-test="shopping-cart-link"]').click();page.locator('[data-test="checkout"]').click()
    for field,value in [('firstName','Learner'),('lastName','Tester'),('postalCode','100000')]:page.locator('[data-test="'+field+'"]').fill(value)
    values={field:page.locator('[data-test="'+field+'"]').input_value() for field in ['firstName','lastName','postalCode']}
    page.locator('[data-test="continue"]').click()
    if page.locator('[data-test="finish"]').is_visible():
        overview={'names':page.locator('.cart_item .inventory_item_name').all_text_contents(),'subtotal':text(page.locator('[data-test="subtotal-label"]'))}
        page.locator('[data-test="finish"]').click()
    else:overview=None
    return {'fields':values,'overview':overview,'url':page.url,'complete':page.locator('[data-test="complete-header"]').is_visible(),'error':page.locator('[data-test="error"]').all_text_contents()}

with sync_playwright() as pw:
    browser=pw.chromium.launch()
    for number,user,password,error in [(1,'standard_user','secret_sauce',None),(2,'unknown_recheck_user','secret_sauce','Username and password do not match'),(3,'standard_user','wrong_password','Username and password do not match'),(4,'','secret_sauce','Username is required'),(5,'standard_user','','Password is required'),(6,'','','Username is required')]:
        name=f'TC-{number:03}';context,page=session(browser,name);login(page,user,password)
        def verify_login():
            if error:expect(page.locator('[data-test="error"]')).to_contain_text(error);return text(page.locator('[data-test="error"]'))
            expect(page.locator('[data-test="title"]')).to_have_text('Products');return 'Products'
        check(page,name,verify_login);close(context,name)
    context,page=session(browser,'baseline-products');login(page);expect(page.locator('.inventory_item')).to_have_count(6)
    baseline=items(page);results['reference_products']=baseline
    def verify_product(n):
        current=items(page)
        if n==7:assert len(current)==6
        if n==8:assert len({i['name'] for i in current})==6 and all(i['name'] for i in current)
        if n==9:assert all(page.locator('img.inventory_item_img').nth(i).evaluate('(img)=>img.complete && img.naturalWidth>0') for i in range(6))
        if n==10:assert all(float(i['price'].replace('$',''))>0 for i in current)
        return current
    for n in range(7,11):check(page,f'TC-{n:03}',lambda n=n:verify_product(n))
    page.get_by_text(baseline[0]['name'],exact=True).click()
    def detail():
        result={'name':text(page.locator('.inventory_details_name')),'price':text(page.locator('.inventory_details_price')),'image':urljoin(BASE,page.locator('img.inventory_details_img').get_attribute('src')),'description':text(page.locator('.inventory_details_desc'))}
        return result
    def check_detail():
        expect(page.locator('.inventory_details_name')).to_have_text(baseline[0]['name']);return detail()
    check(page,'TC-011',check_detail)
    def compare_detail():
        actual=detail();assert actual==baseline[0],actual;return actual
    check(page,'TC-012',compare_detail)
    page.locator('[data-test="back-to-products"]').click()
    check(page,'TC-013',lambda: expect(page.locator('.inventory_item')).to_have_count(6))
    page.reload(wait_until='domcontentloaded')
    check(page,'TC-014',lambda:expect(page.locator('.inventory_item')).to_have_count(6))
    add(page,baseline[0]['name'])
    check(page,'TC-016',lambda:expect(page.locator('[data-test="shopping-cart-badge"]')).to_have_text('1'))
    page.locator('[data-test="shopping-cart-link"]').click();page.locator('.cart_item').get_by_role('button',name='Remove',exact=True).click()
    check(page,'TC-017',lambda:expect(page.locator('.cart_item')).to_have_count(0))
    page.locator('[data-test="continue-shopping"]').click();add(page,baseline[0]['name']);add(page,baseline[1]['name']);page.locator('[data-test="shopping-cart-link"]').click()
    def cart_compare():
        names=page.locator('.cart_item .inventory_item_name').all_text_contents();assert names==[baseline[0]['name'],baseline[1]['name']];expect(page.locator('[data-test="shopping-cart-badge"]')).to_have_text('2');return names
    check(page,'TC-018',cart_compare)
    page.locator('[data-test="checkout"]').click();page.locator('[data-test="continue"]').click()
    check(page,'TC-019',lambda:expect(page.locator('[data-test="error"]')).to_have_text('Error: First Name is required'))
    for field,value in [('firstName','Learner'),('lastName','Tester'),('postalCode','100000')]:page.locator('[data-test="'+field+'"]').fill(value)
    page.locator('[data-test="continue"]').click();page.locator('[data-test="finish"]').click()
    check(page,'TC-020',lambda:expect(page.locator('[data-test="complete-header"]')).to_have_text('Thank you for your order!'))
    close(context,'baseline-products')
    context,page=session(browser,'normal-account-comparison');login(page,'performance_glitch_user');expect(page.locator('.inventory_item')).to_have_count(6)
    def compare_accounts():
        actual=items(page);assert actual==baseline;return {'account':'performance_glitch_user','products':actual}
    check(page,'TC-015',compare_accounts);close(context,'normal-account-comparison')
    for user in ['standard_user','problem_user','visual_user']:
        for repetition in range(1,3):
            label=user+'-'+str(repetition);context,page=session(browser,label);login(page,user);expect(page.locator('.inventory_item')).to_have_count(6)
            current=items(page);observation={'user':user,'repetition':repetition,'list':current,'list_screenshot':shot(page,label+'-list'),'details':[]}
            results['accounts'].append(observation);save()
            for item in current:
                page.get_by_text(item['name'],exact=True).click();actual=detail()
                mismatch={key:{'list':item[key],'detail':actual[key]} for key in item if item[key]!=actual[key]}
                observation['details'].append({'selected':item['name'],'actual':actual,'mismatch':mismatch,'url':page.url,'screenshot':shot(page,label+'-detail-'+str(len(observation['details'])))})
                page.locator('[data-test="back-to-products"]').click()
            add(page,'Sauce Labs Backpack');add(page,'Sauce Labs Bike Light');page.locator('[data-test="shopping-cart-link"]').click()
            observation['cart']={'requested':['Sauce Labs Backpack','Sauce Labs Bike Light'],'actual':page.locator('.cart_item .inventory_item_name').all_text_contents(),'screenshot':shot(page,label+'-cart')}
            page.locator('[data-test="continue-shopping"]').click();observation['checkout']=checkout(page);observation['checkout']['screenshot']=shot(page,label+'-checkout')
            save();print(label,'observed',flush=True);close(context,label)
    for repetition in range(1,3):
        label='empty-cart-'+str(repetition);context,page=session(browser,label);login(page);page.locator('[data-test="shopping-cart-link"]').click();expect(page.locator('.cart_item')).to_have_count(0)
        before=shot(page,label+'-before');page.locator('[data-test="continue-shopping"]').click();actual=checkout(page);actual.update({'repetition':repetition,'user':'standard_user','empty_before':True,'before_screenshot':before,'after_screenshot':shot(page,label+'-after')});results['empty_cart'].append(actual);save();print(label,actual['complete'],flush=True);close(context,label)
    browser.close()
results['finished_at']=datetime.now(timezone(timedelta(hours=8))).isoformat();results['browser']='Chromium '+pw.chromium.name
save()
print('Recheck completed',flush=True)
