from pathlib import Path
import json

prefix=Path(__file__).with_name('recheck_site.py').read_text(encoding='utf-8').split('with sync_playwright() as pw:')[0]
exec(compile(prefix,'recheck_helpers','exec'))
results=json.loads((OUT/'results.json').read_text(encoding='utf-8'))
with sync_playwright() as pw:
    browser=pw.chromium.launch()
    results['browser_version']=browser.version
    for observation in results['accounts']:
        user=observation['user'];label=user+'-'+str(observation['repetition'])+'-flow'
        context,page=session(browser,label);login(page,user)
        add(page,'Sauce Labs Backpack');add(page,'Sauce Labs Bike Light')
        page.locator('[data-test="shopping-cart-link"]').click();expect(page.locator('[data-test="title"]')).to_have_text('Your Cart')
        observation['cart']={'requested':['Sauce Labs Backpack','Sauce Labs Bike Light'],'actual':page.locator('.cart_item .inventory_item_name').all_text_contents(),'screenshot':shot(page,label+'-cart')}
        page.locator('[data-test="continue-shopping"]').click();expect(page.locator('[data-test="title"]')).to_have_text('Products')
        observation['checkout']=checkout(page);observation['checkout']['screenshot']=shot(page,label+'-checkout')
        save();print(label,json.dumps(observation['checkout'],ensure_ascii=False),flush=True);close(context,label)
    results['empty_cart']=[]
    for repetition in range(1,3):
        label='empty-confirmed-'+str(repetition);context,page=session(browser,label);login(page)
        page.locator('[data-test="shopping-cart-link"]').click();expect(page.locator('[data-test="title"]')).to_have_text('Your Cart');expect(page.locator('.cart_item')).to_have_count(0)
        before=shot(page,label+'-before');page.locator('[data-test="continue-shopping"]').click();expect(page.locator('[data-test="title"]')).to_have_text('Products')
        actual=checkout(page);actual.update({'repetition':repetition,'user':'standard_user','empty_before':True,'before_screenshot':before,'after_screenshot':shot(page,label+'-after')});results['empty_cart'].append(actual);save();print(label,actual['complete'],flush=True);close(context,label)
    results['extensions']=[]
    context,page=session(browser,'EXT-001');login(page,password='wrong_password');expect(page.locator('[data-test="error"]')).to_be_visible();login(page)
    results['extensions'].append({'id':'EXT-001','scenario':'错误密码后修正登录','status':'Pass','screenshot':shot(page,'EXT-001')});close(context,'EXT-001')
    for code,missing in [('EXT-002','lastName'),('EXT-003','postalCode')]:
        context,page=session(browser,code);login(page);add(page,'Sauce Labs Backpack');page.locator('[data-test="shopping-cart-link"]').click();expect(page.locator('[data-test="title"]')).to_have_text('Your Cart');page.locator('[data-test="checkout"]').click()
        for field,value in [('firstName','Learner'),('lastName','Tester'),('postalCode','100000')]:
            if field!=missing:page.locator('[data-test="'+field+'"]').fill(value)
        page.locator('[data-test="continue"]').click();expected='Error: Last Name is required' if missing=='lastName' else 'Error: Postal Code is required';expect(page.locator('[data-test="error"]')).to_have_text(expected)
        results['extensions'].append({'id':code,'scenario':missing+'必填校验','status':'Pass','actual':expected,'screenshot':shot(page,code)});close(context,code)
    browser.close()
results['finished_at']=datetime.now(timezone(timedelta(hours=8))).isoformat();save()
print('Checkout, cart and acceptance-gap checks completed.',flush=True)
